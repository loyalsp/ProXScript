<ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow ">
    <li class="m-menu__section ">
        <h4 class="m-menu__section-text">
            Main Menu
        </h4>
        <i class="m-menu__section-icon flaticon-more-v3"></i>
    </li>

    <li class="m-menu__item  m-menu__item--submenu {{ Request::is('admin/dashboard')? 'm-menu__item--open m-menu__item--expanded' : '' }}"
        aria-haspopup="true" m-menu-submenu-toggle="hover">
        <a href="javascript:;" class="m-menu__link m-menu__toggle">
            <i class="m-menu__link-icon flaticon-layers"></i>
            <span class="m-menu__link-text">
				Home
			</span>
            <i class="m-menu__ver-arrow la la-angle-right"></i>
        </a>
        <div class="m-menu__submenu ">
            <span class="m-menu__arrow"></span>
            <ul class="m-menu__subnav">
                <li class="m-menu__item  m-menu__item--parent" aria-haspopup="true">
					<span class="m-menu__link">
						<span class="m-menu__link-text">
							Home
						</span>
					</span>
                </li>
                <li class="m-menu__item {{ Request::is('admin/dashboard') ? 'm-menu__item--active' : '' }}"
                    aria-haspopup="true">
                    <a href="{{ route('dashboard') }}" class="m-menu__link ">
                        <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                            <span></span>
                        </i>
                        <span class="m-menu__link-text">
							Dashboard
						</span>
                    </a>
                </li>
                <li class="m-menu__item " aria-haspopup="true">
                    <a href="/profile" class="m-menu__link ">
                        <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                            <span></span>
                        </i>
                        <span class="m-menu__link-text">
							My Profile
						</span>
                    </a>
                </li>
                <li class="m-menu__item " aria-haspopup="true">
                    <a href="{{ route('logout') }}"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                       class="m-menu__link ">
                        <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                            <span></span>
                        </i>
                        <span class="m-menu__link-text">
							{{ __('Logout') }}
						</span>
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </li>
            </ul>
        </div>
    </li>


    @php($routes= getAdminRoutes())
    @php($current_route= Route::currentRouteName())
    @php($super_admin= superAdmin())
    @if($super_admin)

        @foreach($routes as $key => $route_list)
            @php($routeNames = array_keys($route_list))
            @if($key=='skip')
                @continue;
            @endif
            <li class="m-menu__item  m-menu__item--submenu {{in_array($current_route,$routeNames) ? 'm-menu__item--open m-menu__item--expanded' : '' }}"
                aria-haspopup="true" m-menu-submenu-toggle="hover">
                <a href="javascript:;" class="m-menu__link m-menu__toggle">
                    <i class="m-menu__link-icon flaticon-share"></i>
                    <span class="m-menu__link-text">
				{{ucfirst($key)}}
			</span>
                    <i class="m-menu__ver-arrow la la-angle-right"></i>
                </a>
                @foreach($route_list as $route => $routeLabel)
                    @if(is_array($route_list[$route]))
                        @continue
                    @endif
                    <div class="m-menu__submenu ">
                        <span class="m-menu__arrow"></span>
                        <ul class="m-menu__subnav">
                            <li class="m-menu__item {{url()->current()==route($route) ? 'm-menu__item--active' : '' }}"
                                aria-haspopup="true">
                                <a href="{{route($route)}}" class="m-menu__link ">
                                    <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                                        <span></span>
                                    </i>
                                    <span class="m-menu__link-text">
							{{$routeLabel}}
						</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                @endforeach

                @endforeach
            </li>
            @else
                @php($permissionFromDb = getUserPermissionFromDb())
                @foreach($routes as $key => $route_list)
                    @php($routeNames = array_keys($route_list))
                    @if($key=='skip' || !in_array_any($routeNames,$permissionFromDb))
                        @continue;
                    @endif
                    <li class="m-menu__item  m-menu__item--submenu {{in_array($current_route,$routeNames) ? 'm-menu__item--open m-menu__item--expanded' : '' }}"
                        aria-haspopup="true" m-menu-submenu-toggle="hover">
                        <a href="javascript:;" class="m-menu__link m-menu__toggle">
                            <i class="m-menu__link-icon flaticon-share"></i>
                            <span class="m-menu__link-text">
				{{ucfirst($key)}}
			</span>
                            <i class="m-menu__ver-arrow la la-angle-right"></i>
                        </a>
                        @foreach($route_list as $route => $routeLabel)
                            @if(is_array($route_list[$route]) || !in_array($route,$permissionFromDb))
                                @continue
                            @endif

                            <div class="m-menu__submenu ">
                                <span class="m-menu__arrow"></span>
                                <ul class="m-menu__subnav">
                                    <li class="m-menu__item {{url()->current()==route($route) ? 'm-menu__item--active' : '' }}"
                                        aria-haspopup="true">
                                        <a href="{{route($route)}}" class="m-menu__link ">
                                            <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                                                <span></span>
                                            </i>
                                            <span class="m-menu__link-text">
							{{$routeLabel}}
						</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        @endforeach

                        @endforeach
                    </li>
                    @endif

</ul>