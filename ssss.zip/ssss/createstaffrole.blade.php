@extends('admin.layouts.master')

@section('title',trans('app.addstaffrole.title'))
@section('subtitle', trans('app.addstaffrole.title'))
@section('subheading', trans('app.addstaffrole.subheading'))
@section('parentBread', trans('app.addstaffrole.parentBread'))
@section('child_1Bread', trans('app.addstaffrole.child_1Bread'))

@section('content')


    @if(isset($pageDescriptions))
        <div class="m-alert m-alert--icon m-alert--air m-alert--square alert alert-dismissible m--margin-bottom-30"
             role="alert">
            <div class="m-alert__icon">
                <i class="flaticon-exclamation m--font-primary"></i>
            </div>
            <div class="m-alert__text">
                {{$pageDescriptions}}
            </div>
        </div>
    @endif


    <!--begin::Portlet-->
    <form class="m-form m-form--fit m-form--label-align-right" id="aclrole" novalidate="novalidate">
        {{csrf_field()}}
        <input name="id" id="id" value="{{isset($role['id']) ? $role['id'] :'0'}}" type="hidden">
        <input name="type" id="type" value="1" type="hidden">
        <div class="row">
            <div class="col-lg-6 col-sm-12 col-xs-6">
                <div class="m-portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    Staff Memeber
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <div class="form-group m-form__group">
                            <div class="row">
                                <label class="col-form-label col-lg-3 col-sm-12">Role Name *</label>
                                <div class="col-lg-9 col-md-9 col-sm-12">
                                    <input type="text" class="form-control m-input" name="role_name"
                                           placeholder="Role Name"
                                           value="{{isset($role['role_name']) ? $role['role_name'] :''}}">
                                </div>
                            </div>
                        </div>
                        <div class="form-group m-form__group pt0">
                            <div class="row pt0">
                                <span class="col-lg-3"></span>
                                <div class="col-lg-9 col-md-9 col-sm-12">
                                    <button id="submit" class="btn btn-success">Update</button>
                                    <button type="reset" class="btn btn-secondary">Cancel</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-sm-12 col-xs-6">
                <div class="m-portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-caption">
                            <div class="m-portlet__head-title">
                                <h3 class="m-portlet__head-text">
                                    Staff role Permissions
                                </h3>
                            </div>
                        </div>
                    </div>
                    @php($permissions = getAdminPermissions())
                    @php($permissionsFromDB = false)

                    @if(isset($role))
                        @php($permissionsFromDB = $role->permissions)
                        @php($permissionsFromDB = json_decode($permissionsFromDB))
                        @php($permissionsFromDB = $permissionsFromDB[1])
                        @php(isset($permissionsFromDB->permissions) ?$permissionsFromDB = $permissionsFromDB->permissions:$permissionsFromDB)

                    @endif
                    <div class="m-portlet__body">
                        <div class="form-group m-form__group row">
                            <!-- <label class="m-checkbox">
                                <input type="checkbox" name="checkboxes"> Option 1
                                <span></span>
                            </label> -->
                            <fieldset>
                                <legend>
                                    <label class="m-checkbox">
                                        <input onclick="selectAllNew(&quot;#parent_92&quot;,&quot;.childs92&quot;)"
                                               type="checkbox" {{!!$permissionsFromDB ?'checked':''}} id="parent_92">
                                        Select
                                        <span></span>
                                    </label>
                                    <a data="parent_92"
                                       onclick="selectAllNew(&quot;#parent_92&quot;,&quot;.childs92&quot;)">
                                        (All)
                                    </a>
                                </legend>
                                <div class="mt-checkbox-list" data-error-container="#form_2_services_error">
                                    <ul class="list-unstyled">
                                        <li>
                                            @php($routes= getAdminRoutes())
                                            @foreach($routes as $key => $route_list)
                                                @php($keys = array_keys($route_list))
                                                @if($key=='skip')
                                                    @continue;
                                                @endif
                                                @php($attributes = determinInput($key))
                                                @php($cnt = false)
                                                @if(!!$permissionsFromDB)
                                                    @php($cnt = in_array_any($keys,$permissionsFromDB))
                                                @endif
                                                <label class="m-checkbox">
                                                    <input name="{{$key}}" {{$cnt?'checked=""':''}} class="childs92"
                                                           id="{{$attributes['child']}}"
                                                           onclick="selectRoles(&quot;#parent_92&quot;,&quot;.{{$attributes['class']}}&quot;,$(this))"
                                                           type="checkbox"> {{ucfirst($key)}}
                                                    <span></span>
                                                </label>
                                                <ul class="list-unstyled">
                                                    @foreach($route_list as $route => $routeLabel)
                                                        @if(is_array($route_list[$route]))
                                                            <li>
                                                                <label class="m-checkbox">
                                                                    <input name="permissions[]"
                                                                           {{is_array($permissionsFromDB) && in_array($route,$permissionsFromDB) ? 'checked=""':''}} onclick="selectPageAccess(&quot;#parent_92&quot;,&quot;#{{$attributes['child']}}&quot;)"
                                                                           class="childs92 {{$attributes['class']}}"
                                                                           value="{{$route}}"
                                                                           type="checkbox"> {{$routeLabel[0]}}
                                                                    <span></span>
                                                                </label>
                                                            </li>
                                                       @else
                                                        <li>
                                                            <label class="m-checkbox">
                                                                <input name="permissions[]"
                                                                       {{is_array($permissionsFromDB) && in_array($route,$permissionsFromDB) ? 'checked=""':''}} onclick="selectPageAccess(&quot;#parent_92&quot;,&quot;#{{$attributes['child']}}&quot;)"
                                                                       class="childs92 {{$attributes['class']}}"
                                                                       value="{{$route}}"
                                                                       type="checkbox"> {{$routeLabel}}
                                                                <span></span>
                                                            </label>
                                                        </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            @endforeach
                                        </li>
                                    </ul>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!--end::Portlet-->


@endsection



@section('page_style')
    <style type="text/css">

    </style>
@endsection

@section('page_scripts')
    <script src="{{ asset('public/js/crud/createOrUpdateRecord.js') }}" type="text/javascript"></script>
    <script type="text/javascript">
        function selectAll(selector) {

            if ($(selector).eq(0).prop('checked'))
                $(selector).prop('checked', false)
            else
                $(selector).prop('checked', true)

        }
        function selectAllNew(parentID, selector) {

            if ($(selector).eq(0).prop('checked')) {
                $(selector).prop('checked', false);
                $(parentID).prop('checked', false);
            } else {
                $(selector).prop('checked', true);
                $(parentID).prop('checked', true);
                //console.log(parentID);
                //$("#"+className).prop('checked', true);
            }


        }
        function selectPageAccess(parentID, selector) {
            $(selector).prop('checked', true);
            $(parentID).prop('checked', true);
        }
        function selectRoles(parentID, selector, obj) {
            $(selector).prop('checked', obj.prop('checked'));
            if (obj.is(":checked"))
                $(parentID).prop('checked', obj.prop('checked'));
        }
        /**/

        $(document).ready(function () {
            $("#submit").click(function () {
                method = "POST";
                route = '{{route('saveStaffRole')}}';
                formId = "#aclrole";
                messages = {
                    'role_name': "Enter Role Name",
                    'permissions': "Select atleast 1 permissions"
                };
                rules = {
                    'role_name': {
                        required: true,
                    }, 'permissions': {
                        required: true
                    }
                };
                createOrUpdate(method, route, formId, rules, messages)
            });
        });
    </script>
@endsection
