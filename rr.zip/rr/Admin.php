<?php

namespace App\Http\Middleware;

use App\Models\RoleAndPermission;
use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

class Admin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = Auth::user();
        if (!is_null($user) && $user->is_admin == 1) {
           // $superAdmin = superAdmin();
            //$current_route = \Request::route()->getName();
      /*    $adminPermissions = getAdminPermissions();
            if($superAdmin || in_array($current_route,$adminPermissions['skip']))
            {*/
                return $next($request);

           /* else
            {*/
    /*            $role = RoleAndPermission::findOrFail($user->role_id);
                $permissionFromDb = json_decode($role->permissions,true);
                $i = -1;
                foreach ($adminPermissions as $module => $modulePermission)
                {
                    $i++;
                    if($module=='skip')
                        continue;
                    if(!in_array($current_route,$modulePermission))
                        continue;
                    $key = array_search($current_route,$modulePermission);
                    $main_menu = array('menu' => $module,'key' =>$key,'index'=>$i);
                    break;
                }
                if(isset($main_menu))
                {
                    $index = $main_menu['index'];
                    $menu_item = $module;
                    $key = $main_menu['key'];
                    if(isset($permissionFromDb[$index][$menu_item])){
                    $dbp = $permissionFromDbForModule = $permissionFromDb[$index][$menu_item];
                        if(!in_array($key,$dbp))
                            return response("Un Authroize Request");
                    }
                    else {
                        return response("Un Authroize Request");
                    }
                }*/

                   //$key = $modulePermission[$key];


            //}
           // return $next($request);
        }
        return redirect('/admin/login');
    }
}
