<?php
/**
 * Created by PhpStorm.
 * User: adnan.rasheed
 * Date: 7/30/2018
 * Time: 9:26 AM
 */

$skip_routes = ['getActivities','saveStaffRole'];

return[
    'logs' => ['ActivitiesPage' => 'Activity Logs','ajax' => 'Ajax Demo'],
    'roles' => ['staffRole' => 'Staff Roles','staffRoleCreate' => 'Create','staffRoleEdit' => ['Edit']],
    'skip' => $skip_routes
];