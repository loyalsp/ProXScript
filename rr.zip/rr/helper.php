<?php
/**
 * Created by PhpStorm.
 * User: adnan.rasheed
 * Date: 7/27/2018
 * Time: 2:04 PM
 */
function getOsList(){
    $os_array       =   array(
        '/windows nt 10.0/i'    =>  'Windows 10',
        '/windows nt 6.2/i'     =>  'Windows 8',
        '/windows nt 6.1/i'     =>  'Windows 7',
        '/windows nt 6.0/i'     =>  'Windows Vista',
        '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     =>  'Windows XP',
        '/windows xp/i'         =>  'Windows XP',
        '/windows nt 5.0/i'     =>  'Windows 2000',
        '/windows me/i'         =>  'Windows ME',
        '/win98/i'              =>  'Windows 98',
        '/win95/i'              =>  'Windows 95',
        '/win16/i'              =>  'Windows 3.11',
        '/macintosh|mac os x/i' =>  'Mac OS X',
        '/mac_powerpc/i'        =>  'Mac OS 9',
        '/linux/i'              =>  'Linux',
        '/ubuntu/i'             =>  'Ubuntu',
        '/iphone/i'             =>  'iPhone',
        '/ipod/i'               =>  'iPod',
        '/ipad/i'               =>  'iPad',
        '/android/i'            =>  'Android',
        '/blackberry/i'         =>  'BlackBerry',
        '/webos/i'              =>  'Mobile'
    );
    return $os_array;
}
function getOS() {

    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];

    $os_platform    =   "Unknown OS Platform";
    $os_array 		= 	getOsList();

    foreach ($os_array as $regex => $value) {

        if (preg_match($regex, $user_agent)) {
            $os_platform    =   $value;
        }

    }

    return $os_platform;

}

function getBrowserList(){
    $browser_array  =   array(
        '/msie/i'       =>  'Internet Explorer',
        '/firefox/i'    =>  'Firefox',
        '/safari/i'     =>  'Safari',
        '/chrome/i'     =>  'Chrome',
        '/opera/i'      =>  'Opera',
        '/netscape/i'   =>  'Netscape',
        '/maxthon/i'    =>  'Maxthon',
        '/konqueror/i'  =>  'Konqueror',
        '/mobile/i'     =>  'Handheld Browser'
    );

    return $browser_array;
}

function getBrowser() {

    $user_agent     =   $_SERVER['HTTP_USER_AGENT'];
    $browser        =   "Unknown Browser";
    $browser_array	= 	getBrowserList();

    foreach ($browser_array as $regex => $value) {

        if (preg_match($regex, $user_agent)) {
            $browser    =   $value;
        }

    }

    return $browser;

}

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    if($ip=='::1')
        $ip = file_get_contents("https://ipapi.co/ip");
    return $ip;
}

function getAuthUser()
{
    return \Illuminate\Support\Facades\Auth::user();
}

function superAdmin()
{
    $user = getAuthUser();
    if($user->id=='1')
        return true;
    return false;
}

function getAdminPermissions()
{
    return \Illuminate\Support\Facades\Config::get('permissions');
}

function canSee()
{
    $user = getAuthUser();
    $role_id = $user->role_id;
    $role = \App\Models\RoleAndPermission::find($role_id);
    return json_decode($role->permissions,true);
}
function determinInput($menu_key)
{
    $array = array();
    switch ($menu_key)
    {
        case 'logs';
            $input ='logs[]';
            $id ='log_clilds';
            $class ='log_class';
            break;

        case 'roles';
            $input ='roles[]';
            $id ='role_clilds';
            $class ='role_class';
            break;
    }
    $array['name'] = $input;
    $array['child'] = $id;
    $array['class'] = $class;

    return $array;
}

function mainMenuPermission($user,$menu_permissions)
{
    $role = \App\Models\RoleAndPermission::find($user->role_id);
    $permissions = json_decode($role->permissions,true);
    $c=0;
    foreach ($permissions as $permission)
    {
        if(isset($permission[$menu_permissions])) {

            $main_menu = $permission[$menu_permissions];
            $c = count($main_menu);
            break;
        }
    }
    if($c>0)
        return true;
    return false;
}

function subMenuPermission($permissions,$key,$menu_index,$parent_loop_index)
{
    $role_permission = canSee();
    $submenu_permission = $role_permission[$parent_loop_index][$key];
    if(in_array($menu_index,$submenu_permission)) {
        return true;
    }
    return false;
}

function getAdminRoutes()
{
    return getAdminPermissions();
}

function getUserPermissionFromDb()
{
    $user = getAuthUser();
    $role_id = $user->role_id;
    $role = \App\Models\RoleAndPermission::find($role_id);
    if(isset($role->permissions))
    $per =  json_decode($role->permissions,true);
        if(isset($per[1]))
    return $per[1]['permissions'];
    return false;
}

function in_array_any($needles, $haystack) {
    return !!array_intersect($needles, $haystack);
}