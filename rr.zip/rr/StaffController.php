<?php

namespace App\Http\Controllers\Admin;

use App\Models\RoleAndPermission;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Repositories\Eloquent\RoleAndPermissionRepo;

class StaffController extends Controller
{
    private $roleAndPermissionRepo;
    /**
     * StaffController constructor.
     */
    public function __construct(RoleAndPermissionRepo $roleAndPermissionRepo)
    {
        $this->roleAndPermissionRepo = $roleAndPermissionRepo;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function staffrole()
    {
       $pageDescriptions = trans('app.staffrole.pageDescriptions');
        return view('admin.staff.viewstaffrole',['pageDescriptions' =>$pageDescriptions]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addstaffrole($id= null)
    {
        $role = RoleAndPermission::find($id);
        $adminPermissions = getAdminPermissions();
        $pageDescriptions = trans('app.addstaffrole.pageDescriptions');
        return view('admin.staff.createstaffrole',['pageDescriptions' =>$pageDescriptions,'role'=>$role,
            'permissions' => $adminPermissions]);
    }

    public function savestaffrole(Request $request)
    {
        $mainMenuList = getAdminPermissions();
        $mainMenuListKeys = array_keys($mainMenuList);
        $count = count($mainMenuListKeys)-1;
        unset($mainMenuListKeys[$count]);
        $rolesAndPermissions = $request->only('permissions');
        $roles = json_encode(array($mainMenuListKeys,$rolesAndPermissions));

        $request->merge([
            'permissions' => $roles
        ]);

        if($request->id>0)
        $saved = $this->roleAndPermissionRepo->updateRecord($request->id,$request->only('permissions','role_name'));
else
        $saved = $this->roleAndPermissionRepo->createRecord($request->only('permissions','role_name'));
    if($saved)
    {
        return response()->json(array('status' => 'success'));
    }
    else   return response()->json(array('status' => 'failed'));
    }
    
}
